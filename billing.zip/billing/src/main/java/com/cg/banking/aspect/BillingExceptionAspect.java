package com.cg.banking.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.exceptions.BillDetailsNotFoundException;

@ControllerAdvice
public class BillingExceptionAspect {
	@ExceptionHandler(BillDetailsNotFoundException.class)
public ModelAndView handleAssociateDetailsNotFoundException(Exception e) {
	return new ModelAndView("findBillDetailsPage","errorMessage",e.getMessage());
}
}
