package com.cg.billing.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillDaoServices extends JpaRepository<BillDaoServices, Integer> {

}
